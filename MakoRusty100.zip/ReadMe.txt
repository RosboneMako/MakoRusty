MAKO RUSTY VST3
Author: Rosbone Mako
Date: 6/20/2024
JUCE Version: 7 (8 should work)

This VST3 is sample code to show how to create a basic Guitar Amp VST.

It also creates a few custom KNOB drawing routines. And uses an image
for the UI background.

The included code is for a JUCE Basic VST project.
It was built on Windows and tested in Reaper (DAW).

The VST is based on simple older style amp where the signal chain is:
Guitar -> Compressor -> Low Cut -> EQ -> Gain -> Speaker

The code also adds an effect I call Chimera that can sweeten up an amp sound.
Chimera creates a low pass and high pass version of the sound. Then slightly
amplifies each separately before mixing them back together. 


ISSUES:
- VST was built on MS C++ 2022 and may require MS Runtime files.

QUICK START HOW TO BUILD IN JUCE
1. Install JUCE PROJUCER.
2. Create a BASIC PLUG-IN project.
3. Edit the project details in DEBUG tab. Title, etc.
4. If you have any images you can drag/drop to the FILE EXPLORER tab.
   These will be added to the project and accessible in your app.
   If you change a file you will need to resave the Juce project so it
   can build the new file into the project code.
4. Save the project. You will see a wait icon as it builds the project.
   No wait icon, means you only saved some file not the whole project.
   Click on the DEBUG or RELEASE tab under EXPORTERS then select SAVE.
5. A folder will be created with many directorties. There will be four files
   in the source directory. Replace them with the provided four files here. 
6. Start Visual Studio (or other) and navigate to the VS solution file.
7. Verify you are in DEBUG mode and press F5 to run. 
   Juce by default lets you build an EXE version which is much easier to debug in. 
   Easy mode is to run/debug the EXE in VS debug mode. 
8. To build the finished VST3, put VS into RELEASE mode and select BUILD from the
   main menu.
9. You will need to dig thru the VS folders of your project to find the VST3 file.
 